<?php

namespace App\Models;

use App\Traits\GlobalScopes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use HasFactory,SoftDeletes,GlobalScopes;

    protected $fillable = [
        'seller_id', 'category_id', 'visible',
        'name', 'description', 'price',
        'discount_type', 'discount_price'
    ];

    public function images()
    {
        return $this->morphMany(File::class,'model');
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function rating()
    {
        return $this->hasMany(Rating::class,'product_id','id')->selectRaw('avg(product_rate) as aggregate, product_id')->groupBy('product_id');
    }

    public function rates()
    {
        return $this->hasMany(Rating::class,'product_id','id');
    }

    public function seller()
    {
        return $this->belongsTo(User::class,'seller_id');
    }
}
