<?php

namespace App\Providers;

use App\Repositories\V1\Contracts\AuthRepositoryInterface;
use App\Repositories\V1\Contracts\CartRepositoryInterface;
use App\Repositories\V1\Contracts\CategoryRepositoryInterface;
use App\Repositories\V1\Contracts\ProductRepositoryInterface;
use App\Repositories\V1\Contracts\RatingRepositoryInterface;
use App\Repositories\V1\Contracts\StoreRepositoryInterface;
use App\Repositories\V1\Contracts\UserRepositoryInterface;
use App\Repositories\V1\Product\CartRepository;
use App\Repositories\V1\Product\CategoryRepository;
use App\Repositories\V1\Product\ProductRepository;
use App\Repositories\V1\Product\RatingRepository;
use App\Repositories\V1\User\AuthRepository;
use App\Repositories\V1\User\StoreRepository;
use App\Repositories\V1\User\UserRepository;
use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(AuthRepositoryInterface::class,AuthRepository::class);
        $this->app->bind(UserRepositoryInterface::class,UserRepository::class);
        $this->app->bind(CategoryRepositoryInterface::class,CategoryRepository::class);
        $this->app->bind(ProductRepositoryInterface::class,ProductRepository::class);
        $this->app->bind(StoreRepositoryInterface::class,StoreRepository::class);
        $this->app->bind(RatingRepositoryInterface::class,RatingRepository::class);
        $this->app->bind(CartRepositoryInterface::class,CartRepository::class);
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
