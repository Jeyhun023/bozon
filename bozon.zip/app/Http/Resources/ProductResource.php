<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ProductResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'seller_id' => $this->seller_id,
            'name' => $this->name,
            'description' => $this->description,
            'price' => (double)$this->price,
            'discount_type' => $this->discount_type,
            'discount_price' => (double)$this->discount_price,
            'rating' => $this->whenLoaded('rating', function () {
                return $this->rating->isNotEmpty() ? round($this->rating[0]->aggregate) : 0;
            }),
            'category' => $this->whenLoaded('category', function () {
                return new CategoryResource($this->category);
            }),
            'seller' => $this->whenLoaded('seller', function () {
                return new UserResource($this->seller);
            }),
            'images' => $this->whenLoaded('images', function () {
                return FileResource::collection($this->images);
            }),
            'rates' => $this->whenLoaded('rates', function () {
                return RatingResource::collection($this->rates);
            }),
        ];
    }
}
