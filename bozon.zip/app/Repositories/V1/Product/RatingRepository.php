<?php


namespace App\Repositories\V1\Product;


use App\Models\Rating;
use App\Repositories\V1\Contracts\RatingRepositoryInterface;
use App\Traits\ApiResponder;

class RatingRepository implements RatingRepositoryInterface
{
    use ApiResponder;

    public function index()
    {
        // TODO: Implement index() method.
    }

    public function store(array $data)
    {
        $data['user_id'] = auth()->user()->id;
        $data['status'] = 0;
       $rating = new Rating;
       $rating->fill($data);
       $rating->save();
       $rating->load(['seller','product']);
       $this->data = $rating;
       return $this->returnData();
    }

    public function show(int $id)
    {
        // TODO: Implement show() method.
    }

    public function update(int $id, array $data)
    {
        // TODO: Implement update() method.
    }

    public function destroy(int $id)
    {
        // TODO: Implement destroy() method.
    }
}
