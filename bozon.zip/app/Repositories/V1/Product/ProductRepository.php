<?php


namespace App\Repositories\V1\Product;


use App\Models\Product;
use App\Repositories\V1\Contracts\ProductRepositoryInterface;
use App\Traits\ApiResponder;
use Illuminate\Pipeline\Pipeline;

class ProductRepository implements ProductRepositoryInterface
{
    use ApiResponder;

    public function index()
    {
        $products = app(Pipeline::class)
            ->send(Product::query()->visible(true))
            ->through([
                \App\QueryFilters\IncludeRelation::class,
                \App\QueryFilters\Price::class,
                \App\QueryFilters\Category::class,
                \App\QueryFilters\Store::class,
            ])
            ->thenReturn()
            ->paginate(8);
        $this->data = $products;
        return $this->returnData();
    }

    public function store(array $data)
    {
        // TODO: Implement store() method.
    }

    public function show(int $id)
    {
        $product = Product::with([
            'rating','category','seller',
            'images','rates.user','rates' => function($query) {
            $query->paginate(8);
        }])->findOrFail($id);
        $this->data = $product;
        return $this->returnData();
    }

    public function update(int $id, array $data)
    {
        // TODO: Implement update() method.
    }

    public function destroy(int $id)
    {
        // TODO: Implement destroy() method.
    }
}
