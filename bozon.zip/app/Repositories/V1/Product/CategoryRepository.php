<?php


namespace App\Repositories\V1\Product;


use App\Models\Category;
use App\Repositories\V1\Contracts\CategoryRepositoryInterface;
use App\Traits\ApiResponder;

class CategoryRepository implements CategoryRepositoryInterface
{
    use ApiResponder;

    /**
     * @return array
     */
    public function index(): array
    {
        $categories = Category::select('id','parent_id','name')->visible(true)->get();
        $this->data = buildCategoryTree($categories);
        return $this->returnData();
    }

    public function store(array $data)
    {
        // TODO: Implement store() method.
    }

    /**
     * @param int $id
     * @return array
     */
    public function show(int $id): array
    {
        $categories = Category::select('id','parent_id','name')->visible(true)->findOrFail($id);
        $this->data = $categories;
        return $this->returnData();
    }

    public function update(int $id, array $data)
    {
        // TODO: Implement update() method.
    }

    public function destroy(int $id)
    {
        // TODO: Implement destroy() method.
    }
}
