<?php


namespace App\Repositories\V1\Contracts;


interface ProductRepositoryInterface extends CrudInterface
{

}
