<?php


namespace App\Repositories\V1\Contracts;


interface AuthRepositoryInterface
{
    public function login(array $credentials): array;

    public function register(array $data): array;

    public function sendCode(string $phone_number): array;

    public function checkVerificationCode(string $phone_number, string $code): array;
}
