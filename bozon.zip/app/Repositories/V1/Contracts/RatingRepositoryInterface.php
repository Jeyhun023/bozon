<?php


namespace App\Repositories\V1\Contracts;


interface RatingRepositoryInterface extends CrudInterface
{

}
