<?php


namespace App\Repositories\V1\User;


use App\Models\User;
use App\Repositories\V1\Contracts\StoreRepositoryInterface;
use App\Traits\ApiResponder;

class StoreRepository implements StoreRepositoryInterface
{
    use ApiResponder;

    public function getAllStores(): array
    {
        $users = User::role('seller')->with('rating')->select('id','full_name','photo')->paginate(8);
        $this->data = $users;
        return $this->returnData();
    }

    public function getStoreById(int $storeId)
    {
        $user = User::role('seller')->with('rating')->findOrFail($storeId);
        $this->data = $user;
        return $this->returnData();
    }
}
