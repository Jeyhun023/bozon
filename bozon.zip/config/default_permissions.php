<?php

return [
    'admin' => [
        'show all'
    ],
    'buyer' => [
        'create post'
    ],
    'seller' => [
        'restore post'
    ],
    'manager' => [
        'create category'
    ],
    'moderator' => [
        'create user'
    ],
    'customer_service' => [
        'show messages'
    ],
    'courier' => [
        'show orders'
    ]
];
