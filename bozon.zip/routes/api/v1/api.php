<?php

use App\Http\Controllers\Api\V1\Auth\LoginController;
use App\Http\Controllers\Api\V1\Auth\RegisterController;
use App\Http\Controllers\Api\V1\Product\CartController;
use App\Http\Controllers\Api\V1\Product\CategoryController;
use App\Http\Controllers\Api\V1\Product\ProductController;
use App\Http\Controllers\Api\V1\Product\RatingController;
use App\Http\Controllers\Api\V1\User\StoreController;
use App\Http\Controllers\Api\V1\User\UserController;
use Illuminate\Support\Facades\Route;

Route::post('user/login',[LoginController::class,'login']);

// Register routes
Route::post('auth/register/sendCode',[RegisterController::class,'sendCode']);
Route::post('auth/register/checkCode',[RegisterController::class,'checkVerificationCode']);
Route::post('auth/register',[RegisterController::class,'register']);

Route::apiResource('categories',CategoryController::class)->only(['index','show']);
Route::apiResource('products',ProductController::class)->only(['index','show']);

Route::get('stores',[StoreController::class,'index']);
Route::get('stores/{storeId}',[StoreController::class,'getStoreById']);

Route::group(['middleware' => 'auth:api'],function (){
    Route::get('auth/me',[UserController::class,'getAuthenticatedUser']);
    Route::post('auth/update',[UserController::class,'update']);
    Route::post('auth/password/update',[UserController::class,'updatePassword']);

    Route::apiResource('categories',CategoryController::class)->except(['index','show']);
    Route::get('cart',[CartController::class,'getCart']);
    Route::post('cart',[CartController::class,'store']);
    Route::post('cart/updateProductCount',[CartController::class,'updateProductCount']);
    Route::delete('cart/{productId}/delete',[CartController::class,'removeProduct']);
    Route::delete('cart/delete',[CartController::class,'removeCart']);
    Route::apiResource('ratings',RatingController::class)->only(['store','update']);
});
