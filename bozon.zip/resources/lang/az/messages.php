<?php

return [
    'created' => 'Məlumat uğurla əlavə edildi.',
    'updated' => 'Məlumat uğurla yeniləndi',
    'deleted' => 'Məlumat uğurla silindi',
    'model_not_found' => 'Seçilən məlumat tapılmadı',
    'relation_not_found' => 'Seçilən əlaqələndirmə tapılmadı',
    'not_updated' => 'Məlumatın yenilənməsi üçün fərqli dəyərlər daxil edin.',
    'password_Not_match' => 'İndiki şifrə köhnə şifrə ilə eyni deyil.',
    'failed' => 'Xəta baş verdi.',
    'product_exists_cart' => 'Məhsul artıq səbətə əlavə olunub.'
];
